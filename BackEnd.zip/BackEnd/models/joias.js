import mongoose from "mongoose"

const exerciseSchema = new mongoose.Schema({
    name:{
        type: String,
        required: true
    },
    price: {
        type: String,
        required: true
    },
    data: [{
        linkImage: String 
    }],
    createadAt: {
        type: Date,
        default: Date.now()
    }
})

export default mongoose.model('Joias', exerciseSchema)