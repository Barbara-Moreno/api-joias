import express from "express";
import mongoose from "mongoose";
import Joias from './models/joias.js';

const app = express();
const port = 3000;

app.use(express.json());

app.get("/joias",async (req, res) => {
  const joias = await Joias.find()
  return res.json(joias);
});

app.get("/joias/:id", async (req, res) => {
  const { id } = req.params;

  try {
    const joias = await Joias.findById(id);

    if (joias) {
      return res.json(joias);
    } else {
      return res.status(404).send("Joias not found");
    }
  } catch (error) {
    console.error("Joias fetching joia:", error);
    return res.status(500).send("Internal Server Error");
  }
});

app.post("/joias", async (request, response) => {
  const joias = request.body;

const newJoias = await Joias.create(joias)

  return response.json(newJoias);
});

app.put("/joias/:id", async (req, res) => {
  const { id } = req.params;
  const joiasData = req.body;

  try {
    const updatedJoias = await joias.findByIdAndUpdate(id, joiasData, {
      new: true,
    });

    if (updatedJoias) {
      return res.json(updatedJoias);
    } else {
      return res.status(404).send("Joias not found");
    }
  } catch (error) {
    console.error("Error updating joias:", error);
    return res.status(500).send("Internal Server Error");
  }
});

app.patch("/joias/:id", async (req, res) => {
  const { id } = req.params;
  const joiasData = req.body;

  try {
    const updatedJoias = await Joias.findByIdAndUpdate(id, joiasData, {
      new: true,
    });

    if (updatedJoias) {
      return res.json(updatedJoias);
    } else {
      return res.status(404).send("Joias not found");
    }
  } catch (error) {
    console.error("Error updating joias:", error);
    return res.status(500).send("Internal Server Error");
  }
});
app.delete("/joias/:id", async (req, res) => {
  const { id } = req.params;

  try {
    const deletedJoias = await Joias.findByIdAndDelete(id);

    if (deletedJoias) {
      return res.status(204).send("Deleted joias"); 
    } else {
      return res.status(404).send("Joias not found");
    }
  } catch (error) {
    console.error("Error deleting joias:", error);
    return res.status(500).send("Internal Server Error");
  }
});

app.listen(port, (err) => {
    if (err) console.log(`error message: ${err}`);
    console.log(`Server listening on http://localhost${port}`);
});

mongoose
  .connect(
    "mongodb+srv://abarbaraandrademoreno:sb6HccUcgBguh0fp@cluster0.kv3ga3q.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
  )
  .then(() => console.log(`Banco conectado`))
  .catch(() => console.log("Não conectado :<"));
